/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package accountvalidation;

/**
 *
 * @author OKECHUKU CHIKELU
 */
import java.util.Scanner;
public class AccountValidation {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args){
         Scanner input = new Scanner(System.in); {
            Login auth = new Login();
            
            System.out.println("User Registration");
            
            System.out.print("Enter username: ");
            String username = input.nextLine();
            
            System.out.print("Enter password: ");
            String password = input.nextLine();
            
            System.out.print("Enter cell phone number: ");
            String phone = input.nextLine();
            
            // Register user
            String registerMessage = auth.registerUser(username, password, phone);
            System.out.println(registerMessage);
            
            if (registerMessage.equals("The user has been registered successfully.")) {
                System.out.println("User Login");
                
                System.out.print("Enter username: ");
                String loginUsername = input.nextLine();
                
                System.out.print("Enter password: ");
                String loginPassword = input.nextLine();
                
                System.out.print("Enter cell phone number: ");
                String loginPhone = input.nextLine();
                
                
            // Attempt login
            String loginStatus = auth.returnLoginStatus(loginUsername, loginPassword, loginPhone);
            System.out.println(loginStatus);
            }
        }
    }
}